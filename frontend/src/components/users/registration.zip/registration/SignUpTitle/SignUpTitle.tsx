import "@/assets/main.css";

export default function SignUpTitle() {
  return <h1 className="create-h1">Create your user profile</h1>;
}
